// INDIA HIRING DASHBOARD - AUTO-UPDATE SCRIPT
// Paste this into Google Sheet > Tools > Script Editor

function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu('Dashboard')
    .addItem('Publish India Data', 'publishIndiaData')
    .addToUi();
}

function publishIndiaData() {
  const sheet = SpreadsheetApp.getActiveSheet();
  const data = extractIndiaHiringData();
  
  // Save to Properties Service (acts as cache)
  const props = PropertiesService.getScriptProperties();
  props.setProperty('lastUpdate', new Date().toISOString());
  props.setProperty('indiaHiringData', JSON.stringify(data));
  
  // Also create/update a public JSON file in Drive
  saveToGoogleDrive(data);
  
  SpreadsheetApp.getUi().alert('✓ India hiring data published! Last updated: ' + new Date().toLocaleString());
}

function extractIndiaHiringData() {
  const sheet = SpreadsheetApp.getActiveSheet();
  const data = sheet.getDataRange().getValues();
  
  const indiaRoles = [];
  const hiredCandidates = [];
  
  let currentSection = '';
  
  for (let i = 0; i < data.length; i++) {
    const row = data[i];
    const firstCol = (row[0] || '').toString().toUpperCase();
    
    // Detect sections
    if (firstCol.includes('CURRENT OPENINGS')) {
      currentSection = 'openings';
      continue;
    }
    if (firstCol.includes('FIRST') && firstCol.includes('LAST') && firstCol.includes('ROLE')) {
      currentSection = 'hired';
      continue;
    }
    
    // Extract India (IND) roles from current openings
    if (currentSection === 'openings' && row[5] && row[5].toString() === 'IND') {
      indiaRoles.push({
        name: row[3] ? row[3].toString().trim() : '',
        reqId: row[8] ? row[8].toString().trim() : '',
        department: row[9] ? row[9].toString().trim() : '',
        recruiter: row[7] ? row[7].toString().trim() : '',
        stage: row[10] ? row[10].toString().trim() : '',
        context: row[11] ? row[11].toString().trim() : '',
        posted: row[13] ? row[13].toString() : 'FALSE',
        daysOpen: calculateDaysOpen(row[14]),
      });
    }
    
    // Extract hired candidates (India location)
    if (currentSection === 'hired' && row[14] && row[14].toString() === 'IND') {
      const acceptedDate = row[9] ? new Date(row[9]) : null;
      const month = acceptedDate ? acceptedDate.toISOString().slice(0, 7) : 'unknown';
      
      hiredCandidates.push({
        name: (row[0] || '') + ' ' + (row[1] || ''),
        role: row[2] ? row[2].toString() : '',
        department: row[3] ? row[3].toString() : '',
        hireDate: row[9] ? row[9].toString() : '',
        timeToFill: row[10] ? parseInt(row[10]) : 0,
        recruiter: row[6] ? row[6].toString() : '',
        month: month,
      });
    }
  }
  
  // Summarize data
  const summary = summarizeIndiaHiring(indiaRoles, hiredCandidates);
  
  return {
    timestamp: new Date().toISOString(),
    summary: summary,
    openRoles: indiaRoles,
    hiredThisMonth: hiredCandidates.filter(c => c.month === new Date().toISOString().slice(0, 7)),
    allHired: hiredCandidates,
  };
}

function calculateDaysOpen(dateString) {
  if (!dateString) return 0;
  try {
    const openDate = new Date(dateString);
    const today = new Date();
    const diffTime = Math.abs(today - openDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  } catch (e) {
    return 0;
  }
}

function summarizeIndiaHiring(roles, hired) {
  const departments = {};
  const recruiters = {};
  
  // Summarize by department
  roles.forEach(role => {
    if (!departments[role.department]) {
      departments[role.department] = { open: 0, target: 0 };
    }
    departments[role.department].open += 1;
  });
  
  // Summarize by recruiter
  roles.forEach(role => {
    if (!recruiters[role.recruiter]) {
      recruiters[role.recruiter] = { open: 0, closed: 0, avgDaysToFill: 0 };
    }
    recruiters[role.recruiter].open += 1;
  });
  
  hired.forEach(h => {
    if (recruiters[h.recruiter]) {
      recruiters[h.recruiter].closed += 1;
      recruiters[h.recruiter].avgDaysToFill = 
        (recruiters[h.recruiter].avgDaysToFill + h.timeToFill) / 2;
    }
  });
  
  return {
    totalOpen: roles.length,
    departments: departments,
    recruiters: recruiters,
    monthlyHires: hired.filter(h => h.month === new Date().toISOString().slice(0, 7)).length,
    avgDaysToFill: hired.length > 0 ? 
      Math.round(hired.reduce((sum, h) => sum + h.timeToFill, 0) / hired.length) : 0,
  };
}

function saveToGoogleDrive(data) {
  try {
    const fileName = 'India_Hiring_Dashboard_Data.json';
    const files = DriveApp.getFilesByName(fileName);
    
    let file;
    if (files.hasNext()) {
      file = files.next();
      file.setContent(JSON.stringify(data, null, 2));
    } else {
      file = DriveApp.createFile(fileName, JSON.stringify(data, null, 2), MimeType.PLAIN_TEXT);
    }
    
    // Make publicly accessible
    file.setSharing(DriveApp.Access.ANYONE, DriveApp.Permission.VIEW);
    
    // Store the download link
    const props = PropertiesService.getScriptProperties();
    props.setProperty('dataFileId', file.getId());
    
    return file.getId();
  } catch (e) {
    Logger.log('Error saving to Drive: ' + e);
  }
}

function autoPublishDaily() {
  // Install time-based trigger in Apps Script dashboard
  // Run > publishIndiaData() at 6 AM daily
  publishIndiaData();
}
