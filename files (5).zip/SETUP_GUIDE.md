# India Talent Acquisition Dashboard - Setup Guide
## Daily Auto-Update via Google Sheets API

---

## PART 1: Set Up Google Apps Script (Automatic Data Publishing)
*Estimated time: 5 minutes*

### Step 1: Open Script Editor
1. Go to your **India hiring Google Sheet** (the one with global + IND data)
2. Click **Tools** → **Script editor**
3. You'll see a new tab with `myFunction()` code

### Step 2: Replace with Dashboard Script
1. **Delete** the existing `myFunction()` code
2. **Paste** the entire contents from `sheets_api_script.gs` (provided above)
3. **Save** (Ctrl+S / Cmd+S)
4. Name the project: "India Hiring Dashboard Auto-Publish"

### Step 3: Authorize the Script
1. Click **Run** → select `publishIndiaData` from dropdown
2. A popup asks for permissions → click **Review Permissions**
3. Choose your Google account
4. Click **Allow** (the script needs permission to read your sheet + write to Drive)
5. Wait for the notification: "✓ India hiring data published!"

### Step 4: Set Daily Auto-Run Trigger
1. In Script Editor, click the **clock icon** ⏰ (Triggers, left sidebar)
2. Click **Create New Trigger** (bottom right)
3. Configure:
   - **Choose which function to run**: `publishIndiaData`
   - **Choose which deployment should run**: Head
   - **Select event source**: Time-driven
   - **Select type of time based trigger**: Day timer
   - **Select time of day**: 6:00 AM - 7:00 AM (or your preference)
4. Click **Save**

✅ **Your data now auto-updates daily at 6 AM!**

The script will:
- Extract all India (IND) roles from your sheet
- Parse pipeline stages (Kick-Off, Sourcing, Interviews, etc.)
- Calculate days open for each position
- Summarize by department & recruiter
- Save as JSON to Google Drive (making it publicly accessible)

---

## PART 2: Get API Credentials (For Dashboard to Read Data)
*Estimated time: 10 minutes*

### Step 1: Get Your File ID
1. Open your India hiring sheet (the global + IND data one)
2. Look at the URL: `https://docs.google.com/spreadsheets/d/[FILE_ID]/edit`
3. Copy the **[FILE_ID]** part (long string of characters)
4. Save it somewhere - you'll need it in a moment

### Step 2: Create Google Cloud Project
1. Go to **[Google Cloud Console](https://console.cloud.google.com)**
2. If you don't have a project, create one:
   - Top left, click dropdown next to "Google Cloud"
   - Click **New Project**
   - Name it: "India Hiring Dashboard"
   - Click **Create**
3. Wait for it to load

### Step 3: Enable Google Drive API
1. In the search bar, type: **Google Drive API**
2. Click on "Google Drive API"
3. Click **Enable**
4. Wait for it to complete

### Step 4: Create API Key
1. Left sidebar → **Credentials**
2. Click **+ Create Credentials** (top)
3. Select **API Key**
4. A popup shows your new API key
5. Click **Copy** and **save it somewhere safe**
6. You can now close this popup

✅ **You now have:**
- File ID
- API Key

---

## PART 3: Configure & Deploy Dashboard
*Estimated time: 5 minutes*

### Option A: Deploy as Standalone Web App (Recommended)

1. **Save this configuration** somewhere accessible:

```
FILE_ID = [your_file_id_from_step_1]
API_KEY = [your_api_key_from_step_4]
```

2. Use the dashboard code provided, replacing:
   - Line ~15: `const SHEET_FILE_ID = 'YOUR_FILE_ID_HERE';` → paste your FILE_ID
   - Line ~16: `const DRIVE_API_KEY = 'YOUR_API_KEY_HERE';` → paste your API_KEY

3. **Deploy to Vercel (Free, 1-click):**
   - Go to [vercel.com](https://vercel.com)
   - Click "Import Project"
   - Paste your GitHub repo OR upload the files
   - Add environment variables (FILE_ID, API_KEY)
   - Click Deploy
   - You get a live URL that updates daily

### Option B: Use as React Component (If You Have Internal App)

1. Install dependencies:
```bash
npm install react recharts
```

2. Import the dashboard component:
```javascript
import IndiaHiringDashboard from './india_hiring_dashboard.jsx';

export default function App() {
  return <IndiaHiringDashboard />;
}
```

3. Update the FILE_ID and API_KEY in the component
4. Deploy with your app

### Option C: Self-Hosted (Node.js Server)

1. Set up a simple Express server that:
   - Reads your India hiring sheet
   - Caches the data (updates every 4 hours)
   - Serves it as JSON endpoint
   - Sends to your dashboard

---

## PART 4: Test & Verify
*5 minutes*

### Test the Script
1. Go back to your Google Sheet
2. Click **Dashboard** menu (top) → **Publish India Data**
3. A notification appears: "✓ India hiring data published!"

### Test the Dashboard
1. Open the dashboard (Vercel link or local app)
2. Wait ~10 seconds for it to load data
3. You should see:
   - Executive summary with your real data
   - All KPI cards populated
   - Department & recruiter data
   - Aging roles highlighted

### Verify Auto-Update
1. In Google Sheet, update any India role (e.g., change a status)
2. The Apps Script will pick it up at 6 AM tomorrow
3. Dashboard auto-refreshes every 4 hours
4. Or click "↻ Refresh now" to see immediate update

---

## PART 5: Troubleshooting

### "Error: Failed to fetch data"
**Solutions:**
1. Check that API_KEY is correct (no extra spaces)
2. Verify FILE_ID matches your sheet
3. Ensure Google Drive API is enabled in Cloud Console
4. Check that the file is publicly accessible (Apps Script made it public)

### "Last updated: never" (Dashboard shows no data)
**Solutions:**
1. Click the Dashboard menu → Publish India Data (manual run)
2. Check Apps Script logs for errors (Execution > View logs)
3. Verify the Apps Script has proper permissions

### Dashboard shows old data
1. Click "↻ Refresh now" button
2. Or wait 4 hours for auto-refresh
3. Or run manual publish in Apps Script

### Only some roles showing (not all India roles)
1. Check that roles have "IND" in Location column (exactly)
2. Check that roles are in the "Current Openings" section
3. Run Apps Script manually to re-publish

---

## QUICK REFERENCE: What Gets Updated

| Metric | Source | Update Frequency |
|--------|--------|-------------------|
| Total Open Positions | Sheet "Current Openings" | Daily (6 AM) |
| Department Breakdown | Filtered by Dept column | Daily (6 AM) |
| Recruiter Performance | Calculated from assigned roles | Daily (6 AM) |
| Pipeline Stages | Parsed from "Status" text field | Daily (6 AM) |
| Aging Analysis | Calculated from "Opened Date" | Daily (6 AM) |
| Monthly Hires | Counted from "Offer Accepted" section | Daily (6 AM) |
| Average Days to Fill | Calculated from acceptance dates | Daily (6 AM) |

---

## ADVANCED: Modify Target & Thresholds

Edit the script to customize:

1. **Monthly Target:** In script, find `const monthlyTarget = 12;` → change to your target
2. **Department Targets:** Add to `summarizeIndiaHiring()` function:
```javascript
departments['R&D'].target = 8;
departments['G&A'].target = 2;
// etc.
```

3. **Auto-Run Time:** In Triggers, edit the time (default is 6 AM daily)

---

## SUPPORT

For issues:
1. Check **Apps Script Execution Logs** (Run > View logs)
2. Verify all column names match exactly (including spaces)
3. Ensure no hidden rows are filtering data
4. Re-authorize the script if permissions lapsed

---

**Setup complete!** 🎉

Your India hiring dashboard now:
✅ Auto-updates daily at 6 AM
✅ Shows real-time hiring metrics
✅ Displays all India roles & status
✅ Tracks recruiter performance
✅ Alerts on aging positions
✅ Updates every 4 hours in the dashboard
