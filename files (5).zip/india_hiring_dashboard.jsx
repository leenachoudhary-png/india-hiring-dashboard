import React, { useState, useEffect } from 'react';

export default function IndiaHiringDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  // Configuration: Replace with your Google Sheet file ID
  const SHEET_FILE_ID = 'YOUR_FILE_ID_HERE'; // Replace with actual ID
  const DRIVE_API_KEY = 'YOUR_API_KEY_HERE'; // Get from Google Cloud Console

  useEffect(() => {
    fetchLiveData();
    // Auto-refresh every 4 hours
    const interval = setInterval(fetchLiveData, 4 * 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const fetchLiveData = async () => {
    setLoading(true);
    setError(null);
    try {
      // Fetch JSON data from Google Drive
      const response = await fetch(
        `https://www.googleapis.com/drive/v3/files/${SHEET_FILE_ID}?alt=media&key=${DRIVE_API_KEY}`
      );

      if (!response.ok) throw new Error('Failed to fetch data');
      const liveData = await response.json();

      setData(liveData);
      setLastUpdated(new Date(liveData.timestamp).toLocaleString());
    } catch (err) {
      setError(err.message);
      console.error('Data fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && !data) {
    return (
      <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-secondary)' }}>
        <p>Loading India hiring data...</p>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div style={{ padding: '2rem', backgroundColor: 'var(--color-background-secondary)', borderRadius: '8px', color: 'var(--color-text-primary)' }}>
        <p><strong>⚠️ Configuration needed:</strong></p>
        <ol style={{ fontSize: '14px', lineHeight: 1.8 }}>
          <li>Get your <strong>Google Sheet File ID</strong> from the URL: <code>docs.google.com/spreadsheets/d/<strong>FILE_ID</strong>/edit</code></li>
          <li>Create a <strong>Google API Key</strong>:
            <ul>
              <li>Go to <a href="https://console.cloud.google.com" target="_blank">Google Cloud Console</a></li>
              <li>Create new project</li>
              <li>Enable "Google Drive API"</li>
              <li>Create API key (Credentials → Create Credentials → API Key)</li>
            </ul>
          </li>
          <li>Replace <code>YOUR_FILE_ID_HERE</code> and <code>YOUR_API_KEY_HERE</code> in the code above</li>
          <li>Run the Google Apps Script (Tools → Script editor → Run publishIndiaData)</li>
        </ol>
        <p style={{ marginTop: '1rem', fontSize: '12px', color: 'var(--color-text-secondary)' }}>Error: {error}</p>
      </div>
    );
  }

  if (!data) return <div>No data available</div>;

  const { summary, openRoles = [], hiredThisMonth = [] } = data;

  // Calculate metrics
  const totalOpen = summary.totalOpen || 0;
  const monthlyTarget = 12; // Update this from your actual target
  const actualHires = hiredThisMonth.length;
  const achievementPercent = Math.round((actualHires / monthlyTarget) * 100);

  // Department analysis
  const deptData = Object.entries(summary.departments || {}).map(([name, stats]) => ({
    name,
    open: stats.open || 0,
    status: name === 'R&D' ? 'at-risk' : name === 'G&A' ? 'on-track' : 'on-track',
  }));

  // Recruiter analysis
  const recruiterData = Object.entries(summary.recruiters || {}).map(([name, stats]) => ({
    name,
    open: stats.open || 0,
    closed: stats.closed || 0,
    avgFill: Math.round(stats.avgDaysToFill || 0),
  }));

  // Aging analysis
  const aging = {
    '0-15 days': openRoles.filter(r => r.daysOpen <= 15).length,
    '16-30 days': openRoles.filter(r => r.daysOpen > 15 && r.daysOpen <= 30).length,
    '31-60 days': openRoles.filter(r => r.daysOpen > 30 && r.daysOpen <= 60).length,
    '60+ days': openRoles.filter(r => r.daysOpen > 60).length,
  };

  const agingRoles = openRoles
    .filter(r => r.daysOpen > 60)
    .sort((a, b) => b.daysOpen - a.daysOpen)
    .slice(0, 3);

  return (
    <div style={{ padding: '1.5rem', fontFamily: 'var(--font-sans)', color: 'var(--color-text-primary)' }}>
      {/* Last Updated */}
      <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginBottom: '1rem' }}>
        Last updated: {lastUpdated} • Auto-refreshes every 4 hours
        <button
          onClick={fetchLiveData}
          style={{
            marginLeft: '1rem',
            padding: '4px 12px',
            fontSize: '11px',
            border: '0.5px solid var(--color-border-tertiary)',
            background: 'var(--color-background-secondary)',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          ↻ Refresh now
        </button>
      </div>

      {/* Executive Summary */}
      <div style={{ marginBottom: '2rem', padding: '1.25rem', backgroundColor: 'var(--color-background-secondary)', borderRadius: '12px', border: '0.5px solid var(--color-border-tertiary)' }}>
        <h2 style={{ fontSize: '16px', fontWeight: 500, marginTop: 0, marginBottom: '0.75rem' }}>India hiring status</h2>
        <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', margin: 0, lineHeight: 1.6 }}>
          <strong>{totalOpen} open positions</strong> across R&D, G&A, Marketing, and Sales. <strong>{achievementPercent}% of monthly target achieved</strong> ({actualHires} of {monthlyTarget} hires). 
          Average time-to-fill: <strong>{summary.avgDaysToFill || '—'} days</strong>. {agingRoles.length} roles require escalation (60+ days open).
        </p>
      </div>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '12px', marginBottom: '2rem' }}>
        <div style={{ backgroundColor: 'var(--color-background-secondary)', padding: '1rem', borderRadius: '8px', border: '0.5px solid var(--color-border-tertiary)' }}>
          <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '0 0 8px' }}>Total open</p>
          <p style={{ fontSize: '24px', fontWeight: 500, margin: 0 }}>{totalOpen}</p>
        </div>
        <div style={{ backgroundColor: 'var(--color-background-secondary)', padding: '1rem', borderRadius: '8px', border: '0.5px solid var(--color-border-tertiary)' }}>
          <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '0 0 8px' }}>Target achievement</p>
          <p style={{ fontSize: '24px', fontWeight: 500, margin: 0 }}>{achievementPercent}%</p>
          <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '6px 0 0' }}>{actualHires} of {monthlyTarget}</p>
        </div>
        <div style={{ backgroundColor: 'var(--color-background-secondary)', padding: '1rem', borderRadius: '8px', border: '0.5px solid var(--color-border-tertiary)' }}>
          <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '0 0 8px' }}>Avg days to fill</p>
          <p style={{ fontSize: '24px', fontWeight: 500, margin: 0 }}>{summary.avgDaysToFill || '—'}</p>
        </div>
        <div style={{ backgroundColor: 'var(--color-background-secondary)', padding: '1rem', borderRadius: '8px', border: '0.5px solid var(--color-border-tertiary)' }}>
          <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '0 0 8px' }}>Aging roles</p>
          <p style={{ fontSize: '24px', fontWeight: 500, margin: 0 }}>{aging['60+ days']}</p>
          <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '6px 0 0' }}>60+ days</p>
        </div>
      </div>

      {/* Department Performance */}
      <div style={{ marginBottom: '2rem' }}>
        <h3 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '1rem' }}>Department performance</h3>
        <div style={{ display: 'grid', gap: '8px' }}>
          {deptData.map((dept) => (
            <div
              key={dept.name}
              style={{
                padding: '1rem',
                backgroundColor: 'var(--color-background-primary)',
                border: '0.5px solid var(--color-border-tertiary)',
                borderRadius: '8px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
                  <span style={{ fontWeight: 500 }}>{dept.name}</span>
                  <span style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                    {dept.status === 'on-track' ? '✓ On Track' : '⚠ At Risk'}
                  </span>
                </div>
              </div>
              <div style={{ textAlign: 'right', fontSize: '12px' }}>
                <p style={{ margin: 0, fontWeight: 500 }}>{dept.open} open</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recruiter Performance */}
      <div style={{ marginBottom: '2rem' }}>
        <h3 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '1rem' }}>Recruiter performance</h3>
        <div style={{ display: 'grid', gap: '8px' }}>
          {recruiterData.map((rec, idx) => (
            <div
              key={idx}
              style={{
                padding: '0.875rem',
                backgroundColor: 'var(--color-background-primary)',
                border: '0.5px solid var(--color-border-tertiary)',
                borderRadius: '8px',
                fontSize: '13px',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                <span style={{ fontWeight: 500 }}>{rec.name}</span>
                <span style={{ color: 'var(--color-text-secondary)' }}>{rec.closed} closed</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px', fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                <div>
                  <span style={{ display: 'block', fontWeight: 500, color: 'var(--color-text-primary)' }}>{rec.open}</span>
                  <span>Open</span>
                </div>
                <div>
                  <span style={{ display: 'block', fontWeight: 500, color: 'var(--color-text-primary)' }}>—</span>
                  <span>Offers</span>
                </div>
                <div>
                  <span style={{ display: 'block', fontWeight: 500, color: 'var(--color-text-primary)' }}>{rec.avgFill}d</span>
                  <span>Avg fill</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Aging Analysis */}
      <div style={{ marginBottom: '2rem' }}>
        <h3 style={{ fontSize: '14px', fontWeight: 500, marginBottom: '1rem' }}>Aging analysis</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: '12px' }}>
          {Object.entries(aging).map(([range, count]) => (
            <div key={range} style={{ padding: '1rem', backgroundColor: 'var(--color-background-primary)', border: '0.5px solid var(--color-border-tertiary)', borderRadius: '8px' }}>
              <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0, marginBottom: '8px' }}>{range}</p>
              <p style={{ fontSize: '20px', fontWeight: 500, margin: 0 }}>{count}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Roles Requiring Action */}
      {agingRoles.length > 0 && (
        <div style={{ padding: '1.25rem', backgroundColor: 'var(--color-background-secondary)', borderRadius: '12px', border: '0.5px solid var(--color-border-tertiary)' }}>
          <h3 style={{ fontSize: '14px', fontWeight: 500, margin: '0 0 1rem' }}>⚠️ Roles requiring escalation (60+ days)</h3>
          <div style={{ display: 'grid', gap: '8px' }}>
            {agingRoles.map((role, idx) => (
              <div key={idx} style={{ padding: '0.75rem', backgroundColor: 'var(--color-background-primary)', borderLeft: '3px solid #D85A30', borderRadius: '4px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '1rem' }}>
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: 0, fontWeight: 500, fontSize: '13px' }}>{role.name}</p>
                    <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'var(--color-text-secondary)' }}>{role.stage}</p>
                  </div>
                  <div style={{ textAlign: 'right', fontSize: '12px', fontWeight: 500, color: '#D85A30' }}>
                    {role.daysOpen} days
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
